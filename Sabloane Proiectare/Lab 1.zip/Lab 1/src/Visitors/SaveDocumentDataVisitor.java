package Visitors;

import Elements.*;

    // TODO : SAVES ALL DATA ON A FILE IN JSON FORMAT !!!

public class SaveDocumentDataVisitor implements Visitor {
    private final String dataFile = "";

    @Override
    public void visitImageProxy(ImageProxy imageProxy) {

    }

    @Override
    public void visitImage(Image image) {

    }

    @Override
    public void visitParagraph(Paragraph paragraph) {

    }

    @Override
    public void visitTable(Tabel table) {

    }

    @Override
    public void visitSection(Section section) {

    }
}
