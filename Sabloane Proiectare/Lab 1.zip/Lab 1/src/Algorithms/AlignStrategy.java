package Algorithms;

public interface AlignStrategy {

    public void printAligned(String text);

}
