package Algorithms;

public class AlignCenter implements AlignStrategy{
    @Override
    public void printAligned(String text) {
        System.out.println("***" + text + "***");
    }
}
